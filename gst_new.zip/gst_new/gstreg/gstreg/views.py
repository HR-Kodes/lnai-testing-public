from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import requests
import numpy as np
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.shortcuts import render
import requests
import numpy as np
import json







class RegistrationProcessView(APIView):
    def post(self, request):
     
        with open('data.json', 'r', encoding='utf-8') as json_file:
            inp = json.load(json_file)
        url = "http://reg.gst.gov.in/registration/"
        response = requests.get(url)
        cookie = response.headers['Set-Cookie'].split(';')[0]
        url = f"https://reg.gst.gov.in/services/captcha?rnd={np.random.random()}"
        headers = {
            "Host": "reg.gst.gov.in",
            "Cookie": cookie,
            "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
            "Referer": "https://reg.gst.gov.in/registration/",
        }
        response = requests.get(url, headers=headers, stream=True)
        if response.status_code == 200:
            with open("captcha.png", "wb") as f:
                for chunk in response.iter_content(chunk_size=128):
                    f.write(chunk)
            print("Captcha image saved as captcha.png")
        else:
            print("Failed to fetch captcha image")
        captchacookie = response.headers['Set-Cookie'].split('; ')[0]
        return captchacookie
        
    

